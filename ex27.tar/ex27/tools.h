/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tools.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mozzart <mozzart@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/04 02:01:49 by mozzart           #+#    #+#             */
/*   Updated: 2019/09/04 02:22:54 by mozzart          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TOOLS_H
# define TOOLS_H

# include <unistd.h>
# include <fcntl.h>
# include <sys/types.h>

void  ft_putchar(char c);
void  ft_putstr(char *str);
void  ft_read_file(char *file_name, int buf_size);

#endif