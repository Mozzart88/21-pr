
#include	"includes/ft_putstr.h"

int main()
{
	ft_putstr("Some coole string");
	return (0);
}